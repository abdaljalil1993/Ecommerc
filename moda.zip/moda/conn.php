<?php
$con=mysqli_connect("localhost","root","","moda1");
?>

