        <nav class="navbar navbar-expand-lg navbar-light " id="navbar">
  <a class="navbar-brand text-uppercase" id="nn" href="#" style="color: #D69B25; font-size: 23px;" >  Moda App</a>
  <button style="border-color: #D69B25;" class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon" ></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarText">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active x" >
        <a class="nav-link a" style="color: #E7E7E8; font-size: 15px;" href="admin.php">Home <span class="sr-only">(current)</span></a>
      </li>
        <li class="nav-item x">
        <a class="nav-link a" style="color: #E7E7E8; font-size: 15px;" href="addpro.php">Add Product</a>
      </li>
          <li class="nav-item x">
        <a class="nav-link a" style="color: #E7E7E8; font-size: 15px;" href="mu.php">Manage Users</a>
      </li>
       <li class="nav-item x">
        <a class="nav-link a" style="color: #E7E7E8; font-size: 15px;" href="mp.php">Manage Products</a>
      </li>
       <li class="nav-item x">
        <a class="nav-link a" style="color: #E7E7E8; font-size: 15px;" href="jr.php">Join Request </a>
      </li>
       <li class="nav-item x">
        <a class="nav-link a" style="color: #E7E7E8; font-size: 15px;" href="cr.php">Competetion Request</a>
      </li>
    </ul>
    <a class="btn btn-outline-warning my-2 my-sm-0 mr-2" href="login.php">LogOut</a>
  </div>
</nav>